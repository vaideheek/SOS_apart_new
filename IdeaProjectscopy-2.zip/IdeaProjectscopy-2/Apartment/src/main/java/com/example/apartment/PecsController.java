package com.example.apartment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class PecsController implements Initializable {
    @FXML
    public MenuItem home;
    @FXML
    public MenuItem addNew;
    @FXML
    public MenuItem logout;
    @FXML
    public  AnchorPane mainPane;
    @FXML
    public MenuBar topMenu;


    @FXML
    public void HandleHome(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(this.getClass().getResource("properties.fxml"));
        Stage Stage = (Stage)this.topMenu.getScene().getWindow();
        Stage.setScene(new Scene(root, 600, 400));


    }
    @FXML
    public void HandleAddNew(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(this.getClass().getResource("AddNew.fxml"));
        Stage Stage = (Stage)this.topMenu.getScene().getWindow();
        Stage.setScene(new Scene(root, 600, 400));


    }
    @FXML
    public void HandleLogout(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(this.getClass().getResource("login-page.fxml"));
        Stage Stage = (Stage)this.topMenu.getScene().getWindow();
        Stage.setScene(new Scene(root, 600, 400));

    }
   @Override
    public void initialize (URL url, ResourceBundle rb){

    }
}