package com.example.apartment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class DebController implements Initializable {
    @FXML
    public MenuItem debhome;
    @FXML
    public MenuItem debaddNew;
    @FXML
    public MenuItem deblogout;
    @FXML
    public AnchorPane debmainPane;
    @FXML
    public MenuBar debtopMenu;


    @FXML
    public void HandleDebHome(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(this.getClass().getResource("properties.fxml"));
        Stage Stage = (Stage)this.debtopMenu.getScene().getWindow();
        Stage.setScene(new Scene(root, 600, 400));


    }
    @FXML
    public void HandleDebAddNew(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(this.getClass().getResource("AddNew.fxml"));
        Stage Stage = (Stage)this.debtopMenu.getScene().getWindow();
        Stage.setScene(new Scene(root, 600, 400));


    }
    @FXML
    public void HandleDebLogout(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(this.getClass().getResource("login-page.fxml"));
        Stage Stage = (Stage)this.debtopMenu.getScene().getWindow();
        Stage.setScene(new Scene(root, 600, 400));

    }
    @Override
    public void initialize (URL url, ResourceBundle rb){

    }
}
