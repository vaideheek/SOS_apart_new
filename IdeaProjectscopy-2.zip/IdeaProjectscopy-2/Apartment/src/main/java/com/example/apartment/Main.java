package com.example.apartment;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("Welcome.fxml"));
        primaryStage.setTitle("Apartment Management");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();


      /*  MenuBar main_menu = new MenuBar();
        Menu Options = new Menu("Options");

        main_menu.getMenus().add(Options);
        BorderPane Root = new BorderPane();
        Root.setTop(main_menu);
        Scene sc = new Scene(Root);
        primaryStage.setScene(sc);
        primaryStage.show();*/

    }

    public static void main(String[] args)  {launch(args);}
}
