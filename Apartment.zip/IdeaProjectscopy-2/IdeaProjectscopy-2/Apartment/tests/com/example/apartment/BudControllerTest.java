package com.example.apartment;

import javafx.event.ActionEvent;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.net.URL;
import java.util.ResourceBundle;

class BudControllerTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getConnection() {
    }

    @Test
    void getDataProperties() {
    }

    @Test
    void showProperties() {
    }

    @Test
    void saveButtonOnAction() {
    }

    @Test
    void TestInitialize() {
        System.out.println("Test successful");
        URL url = null;
        ResourceBundle rb = null;
        BudController instance = new BudController();
        instance.initialize(url, rb);
    }

    @Test
    void handleBudLogout() {
    }



    @Test
    void handleHome() {
    }

    @Test
    void handleAddNew() {
    }

    @Test
    void handleLogout() {
    }

    @Test
    public void saveButtonTest() throws Exception {
        System.out.println("save");
        ActionEvent actionEvent = null;
        BudController BudController = new BudController();
        BudController.SaveButtonOnAction(actionEvent);
    }
}