module com.example.apartment {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
    requires java.desktop;
   // requires mysql.connector.java;

    opens com.example.apartment to javafx.fxml;
    exports com.example.apartment;
}