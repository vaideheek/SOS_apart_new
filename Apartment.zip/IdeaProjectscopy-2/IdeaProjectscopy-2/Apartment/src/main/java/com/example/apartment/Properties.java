package com.example.apartment;

public class Properties {
    int id, bed, price, size;
    String location, type, furnished;

    public Properties(int id, int bed, int price, int size, String location, String type, String furnished) {
        this.id = id;
        this.bed = bed;
        this.price = price;
        this.size = size;
        this.location = location;
        this.type = type;
        this.furnished = furnished;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBed() {
        return bed;
    }

    public void setBed(int bed) {
        this.bed = bed;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFurnished() {
        return furnished;
    }

    public void setFurnished(String furnished) {
        this.furnished = furnished;
    }
}