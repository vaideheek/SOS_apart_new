package com.example.apartment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class DebController implements Initializable {
    @FXML
    public MenuItem debhome;
    @FXML
    public MenuItem debaddNew;
    @FXML
    public MenuItem deblogout;
    @FXML
    public AnchorPane debmainPane;
    @FXML
    public MenuBar debtopMenu;
    @FXML
    private Button savebtn;

    @FXML
    private TableColumn<Properties, String> furCol;

    @FXML
    private TableColumn<Properties, Integer> idCol;

    @FXML
    private TableColumn<Properties, String> locCol;

    @FXML
    private TableColumn<Properties, Integer> priceCol;

    @FXML
    private TableColumn<Properties, Integer> sizeCol;

    @FXML
    private TableColumn<Properties, String> typeCol;
    @FXML
    private TableColumn<Properties, Integer> bedCol;

    @FXML
    private TableView<Properties> table;
    @FXML
    public Button saveButton;
    @FXML
    private Button Addbtn;

    @FXML
    public MenuItem home;
    @FXML
    public MenuItem addnew;
    @FXML
    public MenuItem logout;

    @FXML
    public AnchorPane mainPane;
    @FXML
    public MenuBar topMenu;
    @FXML
    private TextField tfBed;

    @FXML
    private TextField tfFur;

    @FXML
    private TextField tfLoc;

    @FXML
    private TextField tfPrice;

    @FXML
    private TextField tfSize;

    @FXML
    private TextField tfType;


    ObservableList<Properties> listM;

    int index = -1;

    @FXML
    void AddBtn(ActionEvent event) {
        if (event.getSource() == Addbtn) {
            insertRecord();
        }

    }
    private void insertRecord() {
        String query ="INSERT INTO test_.deb(`ID`, `Location`, `Size`, `No of Bedrooms`, `Furnished`, `Type`, `Price`) VALUES (" + tfBed.getText() + ",'" + tfFur.getText() + "','" + tfLoc.getText() + "',"
                + tfPrice.getText() + "," + tfSize.getText() + tfType.getText() + ")";
        executeQuery(query);
        showProperties();
    }


    private void executeQuery(String query) {
        Connection conn = getConnection();
        Statement st;
        try {
            st = conn.createStatement();
            st.executeUpdate(query);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        Connection conn;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_", "chichi", "");
            JOptionPane.showMessageDialog(null, "ConnectionEstablished");
            return conn;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            throw new RuntimeException(e);
            //return conn;
        }
    }

    public  ObservableList<Properties> getDataProperties(){
        Connection conn = getConnection();
        ObservableList<Properties> list = FXCollections.observableArrayList();
        String query = "SELECT * FROM build";
        Statement st;
        ResultSet rs;
        try {
            st = conn.createStatement();
            rs = st.executeQuery(query);
            Properties properties;
            while (rs.next()){
                properties = new Properties(rs.getInt("ID"), rs.getInt("Bed"), rs.getInt("Price"), rs.getInt("Size"), rs.getString("Location"), rs.getString("Furnished"),rs.getString("Type"));
                list.add(properties);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public void showProperties(){
        ObservableList<Properties> list = getDataProperties();
        idCol.setCellValueFactory(new PropertyValueFactory<Properties, Integer>("ID"));
        locCol.setCellValueFactory(new PropertyValueFactory<Properties, String>("Location"));
        sizeCol.setCellValueFactory(new PropertyValueFactory<Properties, Integer>("Size"));
        typeCol.setCellValueFactory(new PropertyValueFactory<Properties, String >("Type"));
        furCol.setCellValueFactory(new PropertyValueFactory<Properties, String>("Furnished"));
        bedCol.setCellValueFactory(new PropertyValueFactory<Properties, Integer>("No of Bedroom"));
        priceCol.setCellValueFactory(new PropertyValueFactory<Properties, Integer>("Price"));

        table.setItems(list);
    }

    //Connection conn = null;
    //ResultSet rs = null;
    //PreparedStatement pst = null;



    @FXML
    public void SaveButtonOnAction(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("properties.fxml"));
        Stage stage = (Stage) savebtn.getScene().getWindow();
        stage.setScene(new Scene(root, 800, 500));

    }

    @Override
    public void initialize (URL url, ResourceBundle rb){
        showProperties();

    }
    @FXML
    public void HandleDebHome(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(this.getClass().getResource("properties.fxml"));
        Stage Stage = (Stage)this.debtopMenu.getScene().getWindow();
        Stage.setScene(new Scene(root, 800, 500));


    }

    @FXML
    public void HandleDebLogout(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(this.getClass().getResource("login-page.fxml"));
        Stage Stage = (Stage)this.debtopMenu.getScene().getWindow();
        Stage.setScene(new Scene(root, 800, 400));

    }

}
