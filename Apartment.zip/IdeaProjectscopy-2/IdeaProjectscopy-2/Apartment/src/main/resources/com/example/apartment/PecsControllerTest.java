import static org.junit.jupiter.api.Assertions.*;

class PecsControllerTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void addBtn() {
    }

    @org.junit.jupiter.api.Test
    void getConnection() {
    }

    @org.junit.jupiter.api.Test
    void getDataProperties() {
    }

    @org.junit.jupiter.api.Test
    void showProperties() {
    }

    @org.junit.jupiter.api.Test
    void saveButtonOnAction() {
    }

    @org.junit.jupiter.api.Test
    void initialize() {
    }

    @org.junit.jupiter.api.Test
    void handleHome() {
    }

    @org.junit.jupiter.api.Test
    void handleLogout() {
    }
}