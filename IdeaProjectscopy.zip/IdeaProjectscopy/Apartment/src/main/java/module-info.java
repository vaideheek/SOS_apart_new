module com.example.apartment {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
   // requires mysql.connector.java;

    opens com.example.apartment;

}


